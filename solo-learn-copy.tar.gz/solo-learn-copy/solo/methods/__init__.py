from solo.methods.base import BaseMethod
from solo.methods.all4one import All4One


METHODS = {
    # base classes
    "base": BaseMethod,
    # methods
    "all4one": All4One,
}
__all__ = [
    "BaseMethod",
    "All4One",
]

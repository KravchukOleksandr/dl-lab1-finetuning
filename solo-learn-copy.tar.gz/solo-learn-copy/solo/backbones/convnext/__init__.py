from .convnext import convnext_tiny as default_convnext_tiny
from .convnext import convnext_small as default_convnext_small
from .convnext import convnext_base as default_convnext_base
from .convnext import convnext_large as default_convnext_large


def convnext_tiny(method, *args, **kwargs):
    return default_convnext_tiny(*args, **kwargs)


def convnext_small(method, *args, **kwargs):
    return default_convnext_small(*args, **kwargs)


def convnext_base(method, *args, **kwargs):
    return default_convnext_base(*args, **kwargs)


def convnext_large(method, *args, **kwargs):
    return default_convnext_large(*args, **kwargs)


__all__ = ["convnext_tiny", "convnext_small", "convnext_base", "convnext_large"]
